name: Yi Tian Xu
id: 260520039

This package contains:
	behavior tree: BT.png
	finite state machine: FMS.png
	description of zombie avoidance: Survivor_ZombieAvoidance.txt
	parameters settings: Parameters.txt

	unity package: zombie.unitypackage